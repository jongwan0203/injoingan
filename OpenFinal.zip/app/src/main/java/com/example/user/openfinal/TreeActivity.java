package com.example.user.openfinal;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class TreeActivity extends AppCompatActivity {

    int [] ImageId1 = {R.drawable.WaterOn,R.drawable.WaterOff};
    int [] ImageId2 = {R.drawable.WindOn, R.drawable.WindOff};
    ImageView iv1,iv2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.Tree);

        iv1 = (ImageView)findViewById(R.id.imageView5);

        iv1.setImageResource(R.drawable.WaterOff);
        iv1.setOnClickListener(new View.OnClickListener() {
            int i=0;
            int length = ImageId1.length;

            @Override
            public void onClick(View v) {
                iv1.setImageResource(ImageId1[i]);
                i+=1;
                if(i== ImageId1.length) i=0;
            }
        });

        iv2 = (ImageView)findViewById(R.id.imageView6);
        iv2.setImageResource(R.drawable.WindOff);
        iv2.setOnClickListener(new View.OnClickListener() {
            int i=0;
            int length = ImageId1.length;

            @Override
            public void onClick(View v) {
                iv2.setImageResource(ImageId2[i]);
                i+=1;
                if(i== ImageId1.length) i=0;
            }
        });

    }
}
