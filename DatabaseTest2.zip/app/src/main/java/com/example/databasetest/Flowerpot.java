package com.example.databasetest;
//화분의 상태를 저장하는 객체
public class Flowerpot {
    public Double Cur_temp;
    public Long Cur_moisture;
    public String Local_weather;

    public boolean Pump_state;
    public boolean LED_state;
    public boolean Fan_state;

    public Flowerpot(){
        this.Cur_temp = null;
        this.Cur_moisture = null;
        this.Local_weather = null;

        this.Pump_state = false;
        this.LED_state = false;
        this.Fan_state = false;
    }

    public Flowerpot(Double Cur_temp, Long Cur_moisture, String Local_weather,boolean Pump_state, boolean LED_state, boolean Fan_state){
        this.Cur_temp = Cur_temp;
        this.Cur_moisture = Cur_moisture;
        this.Local_weather = Local_weather;
        this.Pump_state = Pump_state;
        this.LED_state = LED_state;
        this.Fan_state = Fan_state;
    }
}
