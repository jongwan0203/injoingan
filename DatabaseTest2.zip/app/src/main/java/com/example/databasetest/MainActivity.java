package com.example.databasetest;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.firebase.ui.database.FirebaseListAdapter;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;// 클래스 임포트
import com.google.firebase.database.FirebaseDatabase; // 클래스 임포트
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity {



    private  Button sendBtn,nameUpdateBtn, inputPlantInfo;
    private EditText ID,nameTxt,passwordTxt,locationTxt;
    private  EditText plantNameTxt, plantMinTempTxt, plantMaxTempTxt, plantMinMoistureTxt, plantMaxMoistureTxt;



    public String msg; // 사용자가 입력한 문자열이 저장

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ID = (EditText)findViewById(R.id.editTxt);
        sendBtn = (Button)findViewById(R.id.btn1);
        inputPlantInfo = (Button)findViewById(R.id.btn3);
        nameUpdateBtn = (Button)findViewById(R.id.btn2);


        nameTxt = (EditText)findViewById(R.id.editTxt1);
        passwordTxt = (EditText)findViewById(R.id.editTxt2);
        locationTxt = (EditText)findViewById(R.id.editTxt3);
        plantNameTxt = (EditText)findViewById(R.id.editTxt4);
        plantMinTempTxt = (EditText)findViewById(R.id.editTxt5);
        plantMaxTempTxt = (EditText)findViewById(R.id.editTxt6);
        plantMinMoistureTxt = (EditText)findViewById(R.id.editTxt7);
        plantMaxMoistureTxt = (EditText)findViewById(R.id.editTxt8);




        sendBtn.setOnClickListener(new Button.OnClickListener(){
            public void onClick(View v){
                String userID = ID.getText().toString();
                String name = nameTxt.getText().toString();
                String password = passwordTxt.getText().toString();
                String location = locationTxt.getText().toString();

                User user = new User(name, password,location);

                DatabaseControl control = new DatabaseControl();

                control.writeNewUser(userID,user);
            }
        });

        inputPlantInfo.setOnClickListener(new Button.OnClickListener(){
            public void onClick(View v){
                String userID = ID.getText().toString();
                String plantName = plantNameTxt.getText().toString();
                Double plantMinTemp = Double.parseDouble(plantMinTempTxt.getText().toString());
                Double plantMaxTemp = Double.parseDouble(plantMaxTempTxt.getText().toString());
                Long plantMinMoisture = Long.parseLong(plantMinMoistureTxt.getText().toString());
                Long plantMaxMoisture = Long.parseLong(plantMaxMoistureTxt.getText().toString());

                Plant plant = new Plant(plantName,plantMinTemp,plantMaxTemp,plantMinMoisture,plantMaxMoisture);

                DatabaseControl control = new DatabaseControl();

                control.addPlant(userID,plant);

            }
        });
        nameUpdateBtn.setOnClickListener(new Button.OnClickListener(){
            public void onClick(View v){
                String userID = ID.getText().toString();
                String newPlnatName = plantNameTxt.getText().toString();

                DatabaseControl control = new DatabaseControl();

                control.updateData(userID,newPlnatName);

            }
        });
    }
}