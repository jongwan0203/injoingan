package com.example.databasetest;
//유저의 정보를 저장하는 객체
public class User {

    public String user_name;
    public String user_pw;
    public String myLocation;
    public Object myPlant; // Plant 객체를 저장하는 멤버
    //public Object flowerpot;


    public User() {

        this.user_name = null;
        this.user_pw = null;
        this.myLocation = null;
        this.myPlant = null;
    }

    public User(String user_name, String user_pw ,String myLocation ){
        this.user_name = user_name;
        this.user_pw = user_pw;
        this.myLocation = myLocation;
        this.myPlant = null;
    }
}
